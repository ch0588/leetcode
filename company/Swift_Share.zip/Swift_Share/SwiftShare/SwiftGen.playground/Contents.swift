//: Playground - noun: a place where people can play

import UIKit

//: 1 swiftgen images [OPTIONS] DIR
//: Generated code
extension UIImage {
    enum Asset : String {
        case GreenApple = "Green-Apple"
        case RedApple = "Red-Apple"
        case Banana = "Banana"
        case BigPear = "Big_Pear"
        case StopButtonEnabled = "stop.button.enabled"
        
        var image: UIImage {
            return UIImage(named: self.rawValue)!
        }
    }
    
    convenience init!(asset: Asset) {
        self.init(named: asset.rawValue)
    }
}

//: Usage

let image1 = UIImage(asset: .Banana)   // Prefered way
let image2 = UIImage.Asset.GreenApple.image // Alternate way


//: 2 swiftgen strings /path/to/Localizable.strings
/*
"alert_title" = "Title of the alert";
"alert_message" = "Some alert body there";
"greetings" = "Hello, my name is %@ and I'm %d";
"apples.count" = "You have %d apples";
"bananas.owner" = "Those %d bananas belong to %@.";
*/

//: Generated code
enum L10n {
    /// Title of the alert
    case AlertTitle
    /// Some alert body there
    case AlertMessage
    /// Hello, my name is %@ and I'm %d
    case Greetings(String, Int)
    /// You have %d apples
    case ApplesCount(Int)
    /// Those %d bananas belong to %@.
    case BananasOwner(Int, String)
}

extension L10n : CustomStringConvertible {
    var description : String { return self.string }
    
    var string : String {
        /* Implementation Details */
        return " "
    }

}

func tr(key: L10n) -> String {
    return key.string
}

//: Usage
let title = L10n.AlertTitle.string
// -> "Title of the Alert"

// Alternative syntax, shorter
let msg = tr(.AlertMessage)
// -> "Some alert body there"

// Strings with parameters
let nbApples = tr(.ApplesCount(5))
// -> "You have 5 apples"

// More parameters of various types!
let ban = tr(.BananasOwner(2, "John"))
// -> "Those 2 bananas belong to John."

//: 3 swiftgen colors /path/to/colors-file.txt
//: Source File : MyColors.txt
/*
Cyan         : 0xff66ccff
ArticleTitle : #33fe66
ArticleBody  : 339666
Translucent  : ffffffcc
*/

//: Generated code
extension UIColor {
    /* Private Implementation details */
    
}

extension UIColor {
    enum Name : UInt32 {
        /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#ffffff"></span>
        /// Alpha: 80% <br/> (0xffffffcc)
        case Translucent = 0xffffffcc
        /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#339666"></span>
        /// Alpha: 100% <br/> (0x339666ff)
        case ArticleBody = 0x339666ff
        /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#ff66cc"></span>
        /// Alpha: 100% <br/> (0xff66ccff)
        case Cyan = 0xff66ccff
        /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#33fe66"></span>
        /// Alpha: 100% <br/> (0x33fe66ff)
        case ArticleTitle = 0x33fe66ff
    }
    
    convenience init(named name: Name) {
        let rgbaValue = name.rawValue
        let red   = CGFloat((rgbaValue >> 24) & 0xff) / 255.0
        let green = CGFloat((rgbaValue >> 16) & 0xff) / 255.0
        let blue  = CGFloat((rgbaValue >>  8) & 0xff) / 255.0
        let alpha = CGFloat((rgbaValue      ) & 0xff) / 255.0
        
        self.init(red: red, green: green, blue: blue, alpha: alpha)
    }
}

//: Usage
UIColor(named: .ArticleTitle)
UIColor(named: .ArticleBody)
UIColor(named: .Translucent)




