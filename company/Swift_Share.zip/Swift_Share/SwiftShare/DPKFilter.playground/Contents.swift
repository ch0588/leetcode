//: Playground - noun: a place where people can play

import UIKit

typealias DPKFilterFunction = CIImage -> CIImage
typealias DPKParameters = [String : AnyObject]

extension CIImage { // Applicative
    
    func transformWithFilter(filter: DPKFilter) -> CIImage {
        return filter.filter(self)
    }
}

struct DPKFilter { // 把函数装箱
    
    typealias DPKBindFunction = DPKFilterFunction -> DPKFilter
    
    let filter: DPKFilterFunction
    
    init(filter: DPKFilterFunction) {
        self.filter = filter
    }
    
    private func chain(filter: DPKFilter) -> DPKFilter {
        return DPKFilter { image in
            return filter.filter(self.filter(image))
        }
    }
}


//     public func map<T>(@noescape transform: (Self.Generator.Element) throws -> T) rethrows -> [T]
extension DPKFilter {
    
    static func blur(radius radius: Double) -> DPKFilter { // Functor
        return DPKFilter { (image) -> CIImage in
            let parameters : DPKParameters = [kCIInputRadiusKey: radius, kCIInputImageKey: image]
            let filter = CIFilter(name:"CIGaussianBlur", withInputParameters:parameters)
            return filter!.outputImage!
        }
    }
    
    func blur(radius radius: Double) -> DPKFilter {
        return chain(DPKFilter.blur(radius: radius))
    }
    
    private static func colorGenerator(color: UIColor) -> DPKFilterFunction {
        return { _ in
            let filter = CIFilter(name:"CIConstantColorGenerator", withInputParameters: [kCIInputColorKey: CIColor(color: color)])
            return filter!.outputImage!
        }
    }
    
    private static func compositeSourceOver(overlay: CIImage) -> DPKFilterFunction {
        return { image in
            let parameters : DPKParameters = [
                kCIInputBackgroundImageKey: image,
                kCIInputImageKey: overlay
            ]
            let filter = CIFilter(name:"CISourceOverCompositing", withInputParameters: parameters)
            return filter!.outputImage!.imageByCroppingToRect(image.extent)
        }
    }
    
    static func colorOverlay(color: UIColor) -> DPKFilter {
        return DPKFilter { (image) -> CIImage in
            let overlay = colorGenerator(color)(image)
            return compositeSourceOver(overlay)(image)
        }
    }
    func clorOverlay(color color: UIColor) -> DPKFilter {
        return chain(DPKFilter.colorOverlay(color))
    }
}


let imageFilter = DPKFilter.blur(radius: 5)
                           .clorOverlay(color: UIColor.redColor())
                           .filter

DPKFilter.blur(radius: 5).filter
DPKFilter.colorOverlay(UIColor.redColor()).filter






