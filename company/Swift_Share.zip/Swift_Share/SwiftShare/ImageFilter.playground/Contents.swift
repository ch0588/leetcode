//: Playground - noun: a place where people can play

import UIKit

typealias Parameters = [String : AnyObject]
typealias Filter = CIImage -> CIImage

func blur(radius radius: Double) -> Filter {
    return { image in
        let parameters: Parameters = [kCIInputRadiusKey: radius, kCIInputImageKey: image]
        let filter = CIFilter(name: "CIGaussianBlur", withInputParameters: parameters)
        return filter!.outputImage!
    }
}

func colorGenerator(color: UIColor) -> Filter {
    return { _ in
        let filter = CIFilter(name:"CIConstantColorGenerator", withInputParameters: [kCIInputColorKey: CIColor(color: color)])
        return filter!.outputImage!
    }
}

func compositeSourceOver(overlay: CIImage) -> Filter {
    return { image in
        let parameters : Parameters = [
            kCIInputBackgroundImageKey: image,
            kCIInputImageKey: overlay
        ]
        let filter = CIFilter(name:"CISourceOverCompositing", withInputParameters: parameters)
        return filter!.outputImage!.imageByCroppingToRect(image.extent)
    }
}

func colorOverlay(color: UIColor) -> Filter {
    return { image in
        let overlay = colorGenerator(color)(image)
        return compositeSourceOver(overlay)(image)
    }
}

infix operator >>> { associativity left }
func >>> (f1: Filter,f2: Filter) -> Filter {
    return { img in f2(f1(img)) }
}

let customFilter = blur(radius: 5) >>> colorOverlay(UIColor.redColor())




