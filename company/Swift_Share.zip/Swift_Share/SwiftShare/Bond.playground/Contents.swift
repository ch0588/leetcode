//: Playground - noun: a place where people can play

import UIKit
import XCPlayground
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

class Bond<T> {
    typealias Listener = T -> Void
    var listener: Listener
    
    init(_ listener: Listener) {
        self.listener = listener
    }
    
    func bind(dynamic: Dynamic<T>) {
        dynamic.bonds.append(BondBox(self))
    }
}

class Dynamic<T> {
    var value: T {
        didSet {
            for bondBox in bonds {
                bondBox.bond?.listener(value)
            }
        }
    }
    
    var bonds: [BondBox<T>] = []
    
    init(_ v: T) {
        value = v
    }
}

class BondBox<T> {
    weak var bond: Bond<T>?
    init(_ b: Bond<T>) { bond = b }
}

var name = Dynamic("Bob")
let nameBond = Bond<String>() { name in
    print(name)
}
//nameBond.bind(name)
//name.value = "Charles"

private var handle: UInt8 = 0;
extension UILabel {
    var textBond: Bond<String> {
        if let b: AnyObject = objc_getAssociatedObject(self, &handle) {
            return b as! Bond<String>
        } else {
            let b = Bond<String>() { [unowned self] v in self.text = v }
            objc_setAssociatedObject(self, &handle, b, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
            return b
        }
    }
}

struct viewModel {
    var name = Dynamic("")
    
    mutating func fetchName(completion:() -> Void) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,  Int64(3 * Double(NSEC_PER_SEC))), dispatch_get_main_queue()) { () -> Void in
            self.name.value = "Charles"
            completion()
        }
    }
}

let nameLabel = UILabel()
var vm = viewModel()

nameLabel.textBond.bind(vm.name)
nameLabel.text

print("start fetch")
vm.fetchName { () -> Void in
    print(nameLabel.text!)
}


