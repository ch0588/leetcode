//: Playground - noun: a place where people can play

import Cocoa

//: 1.高阶函数及Curried Function
func sum(a: Int, b: Int) -> Int {
    return a + b
}
sum(3, b: 4)

//(Int, Int) -> Int

func applySum() -> ((Int, Int) -> Int) {
    func sum(a: Int, b: Int) -> Int {
        return a + b
    }
    return sum
}
applySum()(3, 4)

func applySum2(a: Int)(_ b: Int) -> Int { // Curried Function
    return a + b
}
applySum2(2)(3)
let sum = applySum2(2)
sum(3)
sum(4)

//: 2.Map Filter Reduce
// func map<U>(transform: T -> U) -> [U]
let numArr = [1, 2, 3, 4, 5]

var newArr: [Int] = []
for n in numArr {
    newArr.append(n + 2)
} // [3, 4, 5, 6, 7]
newArr

numArr.map { (i) -> Int in
    return i + 2
}

let numArr2 = numArr.map { $0 + 2 }
numArr2
let numArr3 = numArr.map { sum($0) }
numArr3

let strArr = numArr.map{ String($0) }
strArr

// func flatMap<U>(transform: T -> [U]) -> [U]
let arr = [[1,2],[3,4],[5,6]] // [[T]]
let aa = arr.flatMap{$0}// [1, 2, 3, 4, 5]
aa
[1,2]+[3,4]

//func reduce(inital:U, combine:(U, T) -> U) -> U

let numbers = 1...10
var r = numbers.reduce(0) { (total, n) -> Int in
    return total + n
}
r = numbers.reduce(0){ $0+$1 }
r = numbers.reduce(0, combine:+)
r

//func filter(element: T -> Bool) -> [T]
let f = numbers.filter{ $0 % 2 == 0 }
f

numbers.map{ $0 + 1 }
       .filter{ $0 % 2 == 0 }
       .reduce(0, combine: +)
//evenSum

//: composition - Demo - pipe line

//:
extension Array {
    func parallelMap<U>(transform: Element -> U) -> [U] {
        var result: [U?] = Array<U?>(count: count, repeatedValue: nil)
        dispatch_apply(count, dispatch_get_global_queue(0, 0)) {
            result[$0] = transform(self[$0])
        }
        return result.map { $0! }
    }
}

var ns = [11, 12, 13, 14, 15, 16]
ns.parallelMap { (i) -> Int in
//    print(i)
    return i + 10
}
ns[1]


//: Lazy
let nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

let bb = nums.lazy.map { (i) -> Int in
        print("map \(i)")
        return i + 2
    }.first









