//: Playground - noun: a place where people can play

import UIKit

class DynamicString {
    typealias Listener = String -> Void
    var listener: Listener?
    
    func bind(listener: Listener?) {
        self.listener = listener
    }
    
//    func bindAndFire(listener: Listener?) {
//        self.listener = listener
//        listener?(value)
//    }
    
    var value: String {
        didSet {
            listener?(value)
        }
    }
    
    init(_ v: String) {
        value = v
    }
}

let name = DynamicString("Steve")
name.bind { print($0) }

name.value = "Tim"  // prints: Tim
name.value = "Groot" // prints: Groot

class Dynamic<T> {
    typealias Listener = T -> Void
    var listener: Listener?
    
    func bind(listener: Listener?) {
        self.listener = listener
    }
    
    func bindAndFire(listener: Listener?) {
        self.listener = listener
        listener?(value)
    }
    
    var value: T {
        didSet {
            listener?(value)
        }
    }
    
    init(_ v: T) {
        value = v
    }
}


