//: Playground - noun: a place where people can play

import UIKit

//: 1.1 Associated Value,对泛型的支持
enum Either<T1, T2> {
    case First(T1)
    case Second(T2)
}

var either = Either<Int, String>.First(1)
either = Either<Int, String>.Second("a")

if case .First(1) = either {
    print("eq")
}

enum Result_<Value, Error: ErrorType> {
    case Success(Value)
    case Failure(Error)
}

//: 1.2 Recursive Enums
indirect enum Tree {
    case Empty
    case Node(value:Int,left:Tree,right:Tree)
}

extension Tree {
    func evaluateTree() -> Int {
        switch self {
        case .Empty:
            return 0
        case .Node(let value, let left, let right):
            return value + left.evaluateTree() + right.evaluateTree()
        }
    }
}

let tree1 = Tree.Node(value: 1, left: Tree.Empty, right: Tree.Empty)
let tree2 = Tree.Node(value: 2, left: Tree.Empty, right: Tree.Empty)
let tree3 = Tree.Node(value: 3, left: Tree.Empty, right: Tree.Empty)
let tree4 = Tree.Node(value: 4, left: tree1, right: tree2)
let tree5 = Tree.Node(value: 5, left: tree3, right: Tree.Empty)

let tree = Tree.Node(value: 6, left: tree4, right: tree5)

tree.evaluateTree() // 21
UIImage(named: "Tree")
//: 1.3 Option Set

var viewAnimationOptions: UIViewAnimationOptions
viewAnimationOptions = [.Repeat, .CurveEaseInOut, .Autoreverse]

if viewAnimationOptions.contains(.Repeat) {
    true
}

viewAnimationOptions.unionInPlace([.TransitionNone])
if viewAnimationOptions.contains(.TransitionNone) {
    true
}


struct MyFontStyle : OptionSetType {
    let rawValue : Int
    static let Bold             = MyFontStyle(rawValue: 1 << 0)
    static let Italic           = MyFontStyle(rawValue: 1 << 1)
    static let Underline        = MyFontStyle(rawValue: 1 << 2)
    static let Strikethrough    = MyFontStyle(rawValue: 1 << 3)
}

var style: MyFontStyle = [.Bold, .Italic]
style.contains(.Bold)

style = []
style.contains([])
style.isEmpty

style = [.Underline]
style.contains([])
style.isEmpty


//: 1.4 Unit Test
//通过@testable， public 和 internal 都可以被测试了

//: 2 Pattern Match
//: 2.1 if ... let

func testP1(number: Int?, name: String?, view: UIView?) {
    if  let nu = number,
        na = name,
        vi = view
        where nu == 1 {
            print("is \(na),\(vi)")
    } else {
        false
    }
}
testP1(1, name: "", view: UIView())

//: 2.2 guard ,guard是先对非法数据进行处理，提前退出，符合编程习惯。

func validate(name: Any,age: Any) -> Either<(String,Int),NSError> {
    
    guard let n = name as? String else {
        return Either.Second(NSError(domain: "", code: -1, userInfo: nil))
    }
    guard let a = age as? Int else {
        return Either.Second(NSError(domain: "", code: -1, userInfo: nil))
    }
    return Either.First((n,a))
}

validate("yes",age: 1.1)


func validate2(name: Any, age: Any) -> Either<(String, Int), NSError> {
    
    guard let n = name as? String,
              a = age  as? Int
        where a >= 18 else {
            return Either.Second(NSError(domain: "", code: -1, userInfo: nil))
    }
    
    return Either.First((n,a))
}
validate2("y", age: 17)
validate2("y", age: 18)

//: 2.3 if .. case

typealias EitherEnum = Either<(String, Int), NSError>
let firstFunction = EitherEnum.First // Similar to Curried Function
let secondFunction = EitherEnum.Second

let eitherValue = firstFunction(("Bob", 18))

//: old
switch eitherValue {
case .First(let (n, a)) where a >= 18:
    print(">= 18")
default:
    break
}

//: New
if case Either.First(let (n, a)) = eitherValue where a >= 18 {
    print(" >= 18")
}

//: 2.4 for case ... in where

let ages = [1,3,46,18,5,10]
for age in ages {
    if age >= 18 {
        print(" >= 18")
    }
}
//: for in where
for age in ages where age >= 18 {
    print(" >= 18")
}

//: for case in where
let eitherAges = [firstFunction(("y",18)),
                  firstFunction(("b",13)),
                  firstFunction(("c",11)),
                  firstFunction(("dd",22)),
                  secondFunction(NSError(domain: "", code: -1, userInfo: nil))
                ]
var result = ""

for case Either.First(let (n, a)) in eitherAges where a >= 18 {
    // y dd
}
result

//: case的用法：switch case, if case, guard case, for-in case, while case

//: 3. Availability Checking
@available(iOS 9.0, *)
func availableAfterIOS9_0() {
    print("u r after 9.0")
}

func testAvailable() {
    if #available (iOS 9.0, *) { // 代替 isRespondsTo
        availableAfterIOS9_0()
    }
}
testAvailable()

//: 4. Protocol Extensions

//: 4.1 Protocol extension 可以有默认实现

protocol DebugInfoProtocol {
    func debugInfo()
}

extension DebugInfoProtocol {
    func debugInfo() {
        print("debug : \(self)")
    }
}

extension Array: DebugInfoProtocol { }

[1, 3, 4].debugInfo()

//: 4.2 Extension Vs Gloable Function, 多使用extension，少使用全局泛型函数
func countIf<T: CollectionType>(collection: T,
    match: T.Generator.Element -> Bool) -> Int {
        
        var count = 0
        for value in collection where match(value) {
            count++
        }
        return count
}

let c = countIf([1,3,21,33]){ return $0 >= 18 }
c

extension CollectionType {
    func countIf(match: Generator.Element -> Bool) -> Int {
        var count = 0
        for value in self where match(value) {
            count++
        }
        return count
    }
    // FRP的最常用范式是map + filter
    func countIf2(match: Generator.Element -> Bool) -> Int {
        return self.map(match).filter({ $0 }).count
    }
}

let countIf2 = [1,31,21,3,11,33].countIf2({ $0 >= 18})
countIf2


//: 带类型约束的Protocol
extension CollectionType where Generator.Element : Equatable {
    
    public func myIndexOf(element: Generator.Element) -> Index? {
        for i in self.indices {
            if self[i] == element {
                return i }
        }
        return nil
    }
}

//: 可以重写Protocol的默认实现
//extension Array {
//    public func myIndexOf(element: Generator.Element) -> Index? {
//        return nil
//    }
//}


[1, 3, 4].myIndexOf(3)
[1, 3, 4].myIndexOf(2)

//arr.indexOf2(1)

//: 5 Error Handling
//: 5.1 Kinds of Error
//: 1. 无关紧要的错误： 如 Int("ss")可以通过Optional类型返回nil来表示
//: 不要多用，因为对于使用者来说是一种负担
Int("s")

//: 2. 需要知道详细错误信息的

enum APIError : ErrorType {
    
    case ConnectionError(error: NSError)
    case ServerError(statusCode: Int, error: NSError?)
    case NoDataError
    case JSONSerializationError(error: ErrorType)
    case JSONMappingError(error: ErrorType)
}

//: 对于异步结果，可以用Result
enum APIResult<Value, Error: ErrorType> {
    
    case Success(Value)
    case Failure(Error)
    
    func handleError(f: ErrorType -> Void) -> Void {
        
        if case APIResult.Failure(let err) = self {
            f(err)
        }
    }
    
    func map<P>(f: Value -> P) -> APIResult<P,Error> {
        switch self {
        case .Success(let value):
            return .Success(f(value))
        case .Failure(let err):
            return .Failure(err)
        }
    }
}

let resultError = APIResult<String, APIError>.Failure
let resultSucc  = APIResult<String, APIError>.Success

resultError(.NoDataError)
resultError(.ServerError(statusCode: 404, error: nil))
resultSucc("ok")

//: 3. throws

func throwMe(shouldThrow: Bool) throws -> Bool {
    
    if shouldThrow {
        throw APIError.NoDataError
    }
    return true
}

do {
    try throwMe(true)
    
} catch APIError.NoDataError {
    print("no data")
} catch {
    // catch other error
}

//: 3.1 throws 的性能
//: 和 OC 不用，throw error几乎没有性能损失，
//: throws 修饰的返回值其实返回的是一个元组  (returnType, @error ErrorType)

//: 3.2 怎么处理exception？
//: 见Demo,



