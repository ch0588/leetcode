//
//  ViewController.swift
//  SwiftShare
//
//  Created by Dai Dongpeng on 16/2/2.
//  Copyright © 2016年 DD. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

extension ViewController {

}



