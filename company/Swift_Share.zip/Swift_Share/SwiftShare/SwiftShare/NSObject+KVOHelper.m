//
//  NSObject+KVOHelper.m
//  SwiftShare
//
//  Created by Dai Dongpeng on 16/2/2.
//  Copyright © 2016年 DD. All rights reserved.
//

#import "NSObject+KVOHelper.h"

@implementation NSObject (KVOHelper)

- (NSException *)trySetValue:(id)value forKey:(NSString *)key
{
    NSException *result = nil;
    @try {
        [self setValue:value forKey:key];
    }
    @catch (NSException *exception) {
        result = exception;
    }
    return result;
}

@end
