//
//  NSObject+KVOHelper.h
//  SwiftShare
//
//  Created by Dai Dongpeng on 16/2/2.
//  Copyright © 2016年 DD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (KVOHelper)

- (NSException *)trySetValue:(id)value forKey:(NSString *)key;

@end
