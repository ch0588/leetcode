//
//  Bond.swift
//  SwiftShare
//
//  Created by Dai Dongpeng on 16/2/3.
//  Copyright © 2016年 DD. All rights reserved.
//

import UIKit

class Bond<T> {
    typealias Listener = T -> Void
    var listener: Listener
    
    init(_ listener: Listener) {
        self.listener = listener
    }
    
    func bind(dynamic: Dynamic<T>) {
        dynamic.bonds.append(BondBox(self))
    }
}

class Dynamic<T> {
    var value: T {
        didSet {
            for bondBox in bonds {
                bondBox.bond?.listener(value)
            }
        }
    }
    
    var bonds: [BondBox<T>] = []
    
    init(_ v: T) {
        value = v
    }
}

class BondBox<T> {
    weak var bond: Bond<T>?
    init(_ b: Bond<T>) { bond = b }
}

private var handle: UInt8 = 0;

extension UILabel {
    var textBond: Bond<String> {
        if let b: AnyObject = objc_getAssociatedObject(self, &handle) {
            return b as! Bond<String>
        } else {
            let b = Bond<String>() { [unowned self] v in self.text = v }
            objc_setAssociatedObject(self, &handle, b, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
            return b
        }
    }
}

