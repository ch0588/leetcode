//
//  CellViewModel.swift
//  SwiftShare
//
//  Created by Dai Dongpeng on 16/2/3.
//  Copyright © 2016年 DD. All rights reserved.
//

import UIKit

struct CellViewModel: DPKCellDataSource{
//    var title = "Bob"
    var title = Dynamic("Bob")
    var switchOn = true
}


extension CellViewModel: DPKCellDelegate {
    
    func onSwitchTogleOn(on: Bool) {
        if on {

            dispatch_after(dispatch_time(DISPATCH_TIME_NOW,  Int64(3 * Double(NSEC_PER_SEC))), dispatch_get_main_queue()) { () -> Void in
                self.title.value = "Bob"
            }
            print("The Person switch On!")
        } else {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW,  Int64(3 * Double(NSEC_PER_SEC))), dispatch_get_main_queue()) { () -> Void in
                self.title.value = "Charles"
            }
            print("The Person switch Off!")
        }
    }
    
//    var switchColor: UIColor {
//        return .redColor()
//    }
//    
//    var textColor: UIColor {
//        return .blueColor()
//    }
}



