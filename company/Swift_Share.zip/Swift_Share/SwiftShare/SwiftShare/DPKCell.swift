//
//  TabeleViewCell.swift
//  SwiftShare
//
//  Created by Dai Dongpeng on 16/2/3.
//  Copyright © 2016年 DD. All rights reserved.
//

import UIKit

protocol bindable {
    
    typealias DataSourceType
    typealias DelegateType
    
    func bind(dataSource dataSource: DataSourceType, delegate: DelegateType?)
}

protocol DPKCellDataSource {
//    var title: String { get }
    var title: Dynamic<String> { get }
    var switchOn: Bool { get }
}


protocol DPKCellDelegate {
    func onSwitchTogleOn(on: Bool)
    
    var switchColor: UIColor { get }
    var textColor: UIColor { get }
    var font: UIFont { get }
}

extension DPKCellDelegate {
    
    var switchColor: UIColor {
        return .purpleColor()
    }
    
    var textColor: UIColor {
        return .blackColor()
    }
    
    var font: UIFont {
        return .systemFontOfSize(16)
    }
}


class DPKCell : UITableViewCell {
    
    @IBOutlet private weak var label: UILabel!
    @IBOutlet private weak var switchToggle: UISwitch!
    
    private var dataSource: DPKCellDataSource?
    private var delegate: DPKCellDelegate?
    
    func configure(withDataSource dataSource: DPKCellDataSource, delegate: DPKCellDelegate?) {
        self.dataSource = dataSource
        self.delegate = delegate
        
//        label.text = dataSource.title
        label.text = dataSource.title.value
        label.textColor = delegate?.textColor
        
        label.textBond.bind(dataSource.title)
        
        switchToggle.on = dataSource.switchOn
        // color option added!
        switchToggle.onTintColor = delegate?.switchColor
        
    }
    
    @IBAction func onSwitchToggle(sender: UISwitch) {
        delegate?.onSwitchTogleOn(sender.on)
    }
}



