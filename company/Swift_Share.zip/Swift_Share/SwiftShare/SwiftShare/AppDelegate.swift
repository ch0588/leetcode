//
//  AppDelegate.swift
//  SwiftShare
//
//  Created by Dai Dongpeng on 16/2/2.
//  Copyright © 2016年 DD. All rights reserved.
//

import UIKit

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
//        self.testKVC()
//        self.testTryKVC()
        
        return true
    }
}

class Person: NSObject {
    
    dynamic var name = "Bob"

}

extension AppDelegate {
    
    func testKVC() {
        let p = Person()
        
        p.setValue("dd", forKey: "name1") // NSUnknownKeyException
    }
    
    func testTryKVC() {
        let p = Person()
        
        let ex = p.trySetValue("Charles", forKey: "name1")
        
        if let e = ex {
            print("e is \(e)")
        } else {
            print("ok")
        }
    }
}

//extension Person {
//    func registerKVO() -> Void {
//        self.addObserver(self, forKeyPath: "name", options:.New, context:nil)
//    }
//    
//    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
//        print(change)
//    }
//}

