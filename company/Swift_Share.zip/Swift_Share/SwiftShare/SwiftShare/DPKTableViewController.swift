//
//  DPKTableViewController.swift
//  SwiftShare
//
//  Created by Dai Dongpeng on 16/2/3.
//  Copyright © 2016年 DD. All rights reserved.
//

import UIKit

class DPKTableViewController: UITableViewController {
    
    enum CellType: Int {
        case FirstType
        // other settings here
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if let type = CellType(rawValue: indexPath.row) {
            switch type {
            case .FirstType:
                let cell = tableView.dequeueReusableCellWithIdentifier("DPKCell", forIndexPath: indexPath) as! DPKCell
                
                // this is where the magic happens!
                
                let viewmodel = CellViewModel()
                cell.configure(withDataSource: viewmodel, delegate: viewmodel)
                
                return cell
            }
            
        }
        
        return tableView.dequeueReusableCellWithIdentifier("defaultCell", forIndexPath: indexPath)
    }

}