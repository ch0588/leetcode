// throw.swift
enum MyError: ErrorType {
 case SampleError
}
func throwMe(shouldThrow: Bool) throws -> Bool {
 if shouldThrow {
 throw MyError.SampleError 
 }
 return true
}
